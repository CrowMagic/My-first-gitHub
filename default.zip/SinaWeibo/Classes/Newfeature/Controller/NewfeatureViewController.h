//
//  NewfeatureViewController.h
//  SinaWeibo
//
//  Created by user on 15/10/19.
//  Copyright © 2015年 ZT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewfeatureViewController : UIViewController

@end
